package pairOfDice.copy;
import java.util.*;

public class DriverProgram {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		DicePair newPair = new DicePair();
		
		System.out.println("Welcome to the rolling dice program, do you want to roll the dice? Y\\N");
		
		String answer = input.nextLine();
		
		if(answer.equals("Y")) {
			
			System.out.print("\nFirst die is: " + newPair.rollDice1());
			System.out.print("\nSecond die is:" + newPair.rollDice2());
			System.out.print("\nThe total is: " + newPair.sumDie());
			
		}
		
		else System.out.print("\nGoodBye");
		
		
		
		

	}

}
